const endDate = "16 December 2024 12:00 PM";

document.getElementById("end-date").innerHTML = endDate;
const inputs = document.querySelectorAll("input");

const clock = () => {
   const end = new Date(endDate);
   const now = new Date();
//    console.log(end)
//    console.log(now)

//  using 1000 to convert miliseconds intro Seconds
  const diff = (end - now) / 1000;

  if(diff <= 0) {
    document.getElementById("demo").innerHTML = "Hey! It's your birthday today";
    return; // Stop further execution of the function
  }
 

//   console.log(diff);
  inputs[0].value = Math.floor(diff/ 3600 / 24);
  inputs[1].value = Math.floor(diff/ 3600) % 24;
  inputs[2].value = Math.floor(diff/ 60) % 60;
  inputs[3].value = Math.floor(diff) % 60;
}

// inital call
clock()

/*
1 day = 24 hours
1hr = 60 minutes
60 min = 3600 seconds
*/


setInterval(
    () => {
     clock()
    },1000
)